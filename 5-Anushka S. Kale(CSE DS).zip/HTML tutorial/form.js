function validation()
{
    var name = document.getElementById("name").value;
    
    var age = document.getElementById("age").value;
    var email = document.getElementById("email").value;
    
    var phone = document.getElementById("phone").value;
    
    var address = document.getElementById("address").value;
    var emailcheck = /^([a-z A-z 0-9 \. _]+)@([a-z A-Z]+).([a-z A-Z]{2,6})(.[a-z]{2,6})?$/;
    var mobilecheck = /^[7-9]\d{9}$/;
    if(name.trim() == "" || age.trim() == "" || email.trim() == "" || phone.trim() == "" || address.trim() == "")
    {
        alert("Missing Credentials");
        return false;
    }
    else if(emailcheck.test(email)&&mobilecheck.test(phone))
    {
        alert("Your Order is placed Successfully");
        return true;
    }
    else
    {
        alert("Wrong Credentials");
        return false;
    }
}