function val()
{
    //variable holds the value entered by the usrer
    var mobile = document.getElementById("mobile").value 
    var regex=/^[7-9]\d{9}$/

    if(mobile.trim()=="")
    {
        alert("Please Enter a Mobile number");
    }
    else if((regex.test(mobile)))
    {
        alert("Mobile number submitted succesfully")
    }
    else
    {
        alert("Wrong Mobile Number");
    }
}

//we want the ph number starting from 7 8 9