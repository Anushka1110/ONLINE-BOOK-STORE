function validate()
{
    //variable holds the value entered by the usrer
    var email = document.getElementById("email").value 
    var regex=/^([a-z A-z 0-9 \. _]+)@([a-z A-Z]+).([a-z A-Z]{2,6})(.[a-z]{2,6})?$/

    if(email.trim()=="")
    {
        alert("Please Enter a Email Id");
    }
    else if((regex.test(email)))
    {
        alert("Email Id submitted succesfully")
    }
    else
    {
        alert("Wrong Email Id Entered");
    }
}

//anushkakale50@gmail.com
