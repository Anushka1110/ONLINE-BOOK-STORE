
    function convert() {
      var amount = parseFloat(document.getElementById("amount").value);
      var fromCurrency = document.getElementById("from").value;
      var toCurrency = document.getElementById("to").value;

      // Conversion rates (example values)
      var conversionRates = {
        USD: {
          EUR: 0.89,
          INR: 82.10
        },
        EUR: {
          USD: 1.12,
          INR: 91.89
        },
        INR: {
          USD: 0.012,
          EUR: 0.011
        }
      };

      var convertedAmount = amount * conversionRates[fromCurrency][toCurrency];
      document.getElementById("result").innerHTML = convertedAmount.toFixed(2) + " " + toCurrency;
    }
